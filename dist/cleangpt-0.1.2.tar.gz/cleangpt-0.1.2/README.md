### cleangpt

Make GPT's output seem more human-like and non-detectable by GPTZero and such. 

`cleangpt <input_file>.txt` will produce a `clean_gpt_output.txt` file with output.

--------------------------
@author: technoabsurdist
