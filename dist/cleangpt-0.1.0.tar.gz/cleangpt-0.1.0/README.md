### cleangpt

Make GPT's output seem more human-like and non-detectable by GPTZero and such. 
